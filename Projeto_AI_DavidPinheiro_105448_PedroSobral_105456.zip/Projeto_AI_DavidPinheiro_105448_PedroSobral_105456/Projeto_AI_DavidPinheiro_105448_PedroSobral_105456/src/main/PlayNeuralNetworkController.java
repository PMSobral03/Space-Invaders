package main;

import Algoritmo.GeneticAlgorithm;

public class PlayNeuralNetworkController {
	    public static void main(String[] args) {
	    	new GeneticAlgorithm();    	
	    }
	}